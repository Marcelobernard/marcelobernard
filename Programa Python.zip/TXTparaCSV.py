import re
import pandas as pd

# Ler o conteúdo do arquivo .txt

arquivotxt = input('Digite o nome do arquivo para ser lido (ex.: arquivo.txt): ')
ondesalvar = input('Digite o nome do arquivo para ser salvo(ex.: saida.csv): ')
with open(arquivotxt, 'r', encoding='utf-8') as file:
    texto = file.read()

# Ele procura exatamente 'Bairro: ' e depois pega tudo que tiver até encontrar uma quebra de linha, depois ele procura 'Total de Alunos no bairro: ' e pega o número que vier após isso
matches = re.findall(r'Bairro: ([^\n]+).*?Total de Alunos no bairro: (\d+)', texto, re.DOTALL)

cursos = [
    'CIÊNCIA DA COMPUTAÇÃO',
    'DIREITO',
    'ADMINISTRAÇÃO',
    'PEDAGOGIA',
    'PSICOLOGIA',
    'CIÊNCIAS CONTÁBEIS',
    'SISTEMAS DE INFORMAÇÃO',
    'NUTRIÇÃO',
    'ENFERMAGEM',
    'BIOMEDICINA',
    'TURISMO',
    'GESTÃO DA TECNOLOGIA DA I',
    'MARKETING',
    'GESTÃO DE RECURSOS HUMA',
    'ANÁLISE E DESENVOLVIMENT',
    'REDES DE COMPUTADORES',
    'LOGÍSTICA',
    'PROCESSOS GERENCIAIS',
    'GESTÃO COMERCIAL'
]

cursos_por_bairro = {'Bairro': [], 'Quantidade_Alunos': []}
for curso in cursos:
    cursos_por_bairro[curso] = []

# Encontrar e contar a ocorrência de cursos entre "Bairro:" e "Total de Alunos no bairro:"
for bairro, quantidade in matches:
    trecho = re.search(rf'{bairro}(.*?Total de Alunos no bairro: \d+)', texto, re.DOTALL)
    if trecho:
        trecho = trecho.group(1)
        for curso in cursos:
            contador = trecho.count(curso)
            cursos_por_bairro[curso].append(contador)
        cursos_por_bairro['Bairro'].append(bairro)
        cursos_por_bairro['Quantidade_Alunos'].append(quantidade)

df = pd.DataFrame(cursos_por_bairro)

# Salvar em um arquivo CSV
df.to_csv(ondesalvar, index=False)

print(f"Dados salvos em {ondesalvar}")
