import pandas as pd

# Leia os dois arquivos CSV em DataFrames
arquivocsv1 = input('Digite o nome do primeiro arquivo para ser lido(ex.: arquivo.csv): ')
arquivocsv2 = input('Digite o nome do segundo arquivo para ser lido(ex.: arquivo.csv): ')
arquivosaida = input('Digite o nome do arquivo que será criado(ex.: arquivo.csv): ')

df1 = pd.read_csv(arquivocsv1)
df2 = pd.read_csv(arquivocsv2)

# Filtra os DataFrames para conter apenas linhas com o mesmo valor em 'Bairro'
df1_filtrado = df1.groupby('Bairro', as_index=False).sum()
df2_filtrado = df2.groupby('Bairro', as_index=False).sum()

# Junte os DataFrames usando o método concat do pandas
df_merged = pd.concat([df1_filtrado, df2_filtrado])

# Agrupe novamente o DataFrame mesclado por 'Bairro' e some as colunas numéricas
df_merged = df_merged.groupby('Bairro', as_index=False).sum()

# Salve o DataFrame mesclado em um novo arquivo CSV
df_merged.to_csv(arquivosaida, index=False)
