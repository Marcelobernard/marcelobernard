import csv
from unidecode import unidecode

# Função para remover acentos e substituir Ç por C
def limpar_texto(texto):
    texto_sem_acentos = unidecode(texto)
    texto_sem_acentos = texto_sem_acentos.replace('Ç', 'C')
    return texto_sem_acentos

# Nome do arquivo CSV de entrada e saída
nome_arquivo_entrada = input('Digite o nome do arquivo para ser lido(ex.: arquivo.csv): ')
nome_arquivo_saida = input('Digite o nome do arquivo que será criado(ex.: arquivo.csv): ')

# Abrir o arquivo de entrada e criar o arquivo de saída
with open(nome_arquivo_entrada, 'r', newline='', encoding='utf-8') as arquivo_entrada, \
        open(nome_arquivo_saida, 'w', newline='', encoding='utf-8') as arquivo_saida:
    leitor_csv = csv.reader(arquivo_entrada)
    escritor_csv = csv.writer(arquivo_saida)

    # Ler e processar cada linha do arquivo de entrada
    for linha in leitor_csv:
        linha_limpa = [limpar_texto(campo) for campo in linha]
        escritor_csv.writerow(linha_limpa)

print(f'Arquivo {nome_arquivo_entrada} foi processado e salvo como {nome_arquivo_saida}.')
