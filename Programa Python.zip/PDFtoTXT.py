import pdfplumber

arquivopdfin = input('Digite o nome do arquivo PDF (ex.: arquivo.pdf): ')
arquivopdfout = input('Digite o nome do arquivo TXT (ex.: arquivo.txt): ' )
caminhopdf = arquivopdfin # Nome do arquivo de entrada
saidatxt = arquivopdfout # Nome do arquivo de saída

with pdfplumber.open(caminhopdf) as pdf:
    text = ""
    for page in pdf.pages:
        text += page.extract_text()

# Salvar o texto em um arquivo .txt
with open(saidatxt, "w", encoding="utf-8") as txt_file:
    txt_file.write(text)

print(f"Texto extraído e salvo em {saidatxt}")
